//--------------------------------------------------------------------
//
//                                                       listarr.cpp
//
//  SOLUTION: Array implementation of the List ADT
//
//--------------------------------------------------------------------


#include "listarr.h"
#include "algorithm"
#include <fstream>
#include <string>


using namespace std;

//--------------------------------------------------------------------jxxx

List::List(int maxNumber)

// Creates an empty list. Allocates enough memory for maxNumber
// data items (defaults to defMaxListSize).

: maxSize(maxNumber),
size(0),
cursor(-1),i(0)
//dataItems�迭�� maxSize��ŭ�� ũ��� �����Ҵ��ϰ� �ʱ�ȭ ���ش�.
{
	/*dataItems[4];
	list = new char[maxSize];

	for (int j = 0; j < 4; j++)
	{
		dataItems[j] = NULL;
	}
	for (int i = 0; i < maxSize; i++)
		for(int j=0;j<4;j++)
	{
		list[i] = dataItems[j];
	}*/
}

//--------------------------------------------------------------------

List:: ~List()

// Frees the memory used by a list.

{

}

//--------------------------------------------------------------------


void List::read()throw (logic_error)
{

	string filename;
	cout << "Enter the name of the File:";
	cin >> filename;
	filename = filename + ".txt";
	cout << filename;
	/*	do {
			getline(cin, filename);
		} while (cin.fail());*/
	
	std::ifstream inFile(filename);
	char input[100][100];
	for (int j = 0; j<100; j++)
		for (int i = 0; i < 100; i++)
		{
			input[j][i] = NULL;
		}

	while (!inFile.eof())
	{

		inFile.getline(input[i], 100);
		i++;
	}i = i / 4;
	
	for (int k = 0; k<i; k++)
		for (int j = 0; j <4; j++)
		{
			list[k][j] = input[k * 4 + j];
		}
	inFile.close();
}
void List::insert()
throw (logic_error)


{

	char a[100], b[100], c[100];
	i++;

	cin.getline(a, 100);
	cout << "Name :";
	 cin.getline(a, 100);
	list[i][0] = a; cout << endl;
	cout << "Phone :"; cin.getline(b, 100);
	list[i][1] = b; cout << endl;
	cout << "Birthday :"; cin.getline(c, 100);
	list[i][2] = c; cout << endl;
	list[i][3] = "\n";



}

//--------------------------------------------------------------------

void List::remove() throw (logic_error)

// Removes the data items  marked by the cursor from a list. Moves the
// cursor to the next data item item in the list. Assumes that the
// first list data items "follows" the last list data item.

{
	char a[100];
	cin.getline(a, 100);
	cout << "Name :"; cin.getline(a, 100);
	for (int k = 0; k < i; k++)
	{
		if (strcmp(list[k][0], a) == 0)
		{
			for (int j = 0; j < 4; j++)
			{
				list[k][j] = NULL;
			}
			for(int s=k;s<i-1;s++)
				for (int j = 0; j < 4; j++)
				{
					list[s][j] = list[s + 1][j];
				}
			for (int j = 0; j < 4; j++)
			{
				list[i][j] = NULL;
			}
			i--; break;
		}
	}


}

//--------------------------------------------------------------------

//void List::replace(const DataType &newDataItem)
//throw (logic_error)
//
//// Replaces the item marked by the cursor with newDataItem and
//// leaves the cursor at newDataItem.
//
//{
//	// Requires that the list is not empty
//	if (isEmpty() != 1)
//	{
//		dataItems[cursor] = newDataItem;
//	}
//
//}
//
////--------------------------------------------------------------------
//
//void List::clear()
//
//// Removes all the data items from a list.
////list�� ���� NULL�� ä���־� list�� �ʱ�ȭ �ϰ� cursor�� -1�� ��ġ�� �ű��.
//{
//	for (int i = 0; i < maxSize; i++)
//	{
//		dataItems[i] = NULL;
//	}
//	cursor = -1;
//	size = 0;
//}
//
////--------------------------------------------------------------------
//
//bool List::isEmpty() const
//
//// Returns 1 if a list is empty. Otherwise, returns 0.
////�迭 ��ü�� ������� ��� 1�� ��ȯ�ϴ� ���̹Ƿ� dataItems�� ù��° ���� NULL�� ��� 1�� ��ȯ�Ѵ�.
//{
//
//		if (dataItems[0]==NULL)
//		{
//			return 1;
//		}
//		else
//		{
//			return 0;
//		}
//	
//}
//
////--------------------------------------------------------------------
//
//bool List::isFull() const
//
//// Returns 1 if a list is full. Otherwise, returns 0.
////�迭�� NULL���� ������ ��� 0�� ��ȯ�ϰ� �Ѵ�.
//{
//
//	for (int i = 0; i < maxSize; i++)
//	{
//		if (dataItems[maxSize-1] == NULL)
//		{
//			return 0;
//		}
//		else
//		{
//			return 1;
//		}
//	}
//}
//
////--------------------------------------------------------------------
// 
//int List::gotoBeginning() throw (logic_error)
//
//// Moves the cursor to the beginning of the list.
////cursor�� ��ġ�� ó��(0)���� �ű��.
//
//{
//	// pre-lab
//
//	return cursor = 0;
//
//}
//
//
//
////--------------------------------------------------------------------
//
//int List::gotoEnd() throw (logic_error)
//
//// Moves the cursor to the end of the list.
////list�� ���� ������(maxSize-1)�� Ŀ���� �ű��.
//
//{
//	// pre-lab
//
//
//
//
//	return cursor = maxSize-1;
//
//
//}
//
////--------------------------------------------------------------------
//
//bool List::gotoNext() throw (logic_error)
//
//// If the cursor is not at the end of a list, then moves the
//// cursor to the next item in the list and returns true. Otherwise,
//// returns false.
////cursor�� list�� ���� ���� ���� ��쿡 cusror+1�� �Ѵ�. list�� ���� ��ġ�� ��� flase�� ��ȯ�Ѵ�.
//
//{
//	if (cursor != maxSize-1)
//	{
//		cursor++;
//		return true;
//	}
//	else
//	{
//		return false;
//	}
//
//
//
//
//}
//
////--------------------------------------------------------------------
//
//bool List::gotoPrior() throw (logic_error)
//
//// If the cursor is not at the beginning of a list, then moves the
//// cursor to the preceeding item in the list and returns true.
//// Otherwise, returns false.
////cursor�� list�� ó���� ���� ���� ��쿡 cursor-1���Ѵ�.list�� ó���� ��ġ�� ��� false�� ��ȯ�Ѵ�.
//{
//	
//	if (cursor != -1)
//	{
//		cursor--;
//		return true;
//	}
//	else
//	{
//		return false;
//	}
//
//	
//
//
//}

//--------------------------------------------------------------------

//DataType List::getCursor() const throw (logic_error)
//
//// Returns the item marked by the cursor.
////cursor�� ����Ű���ִ� data�� ����Ѵ�.
//{
//	// pre-lab
//
//
//	return dataItems[cursor];
//}

//--------------------------------------------------------------------

//void List::showStructure() const
//
//// Outputs the data items in a list. If the list is empty, outputs
//// "Empty list". This operation is intended for testing/debugging
//// purposes only.
////list�� ����� data���� �ܼ�ȭ�鿡 ��Ÿ����. �� �� index number �� a��� ������ ���� �����ؼ� ����, dataItems�迭�� ���� NULL�� �ƴ� ���� ����ϰ� �Ѵ�.
//{
//	
//	
//	sort(dataItems, dataItems + size);
//	cout << "size of List:" << size << endl;
//	cout << "current location of cursor" << cursor << endl;
//	cout << "---Outputs All data items in a list---" << endl;
//	int a = 0;
//	for (int i = 0; i < maxSize; i++)
//	{
//		
//		if (dataItems[i] != NULL)
//		{
//			cout << a << "-data:" << dataItems[i] << endl; a++;
//		}
//	}
//}
 