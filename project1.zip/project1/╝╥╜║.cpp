//#include <iostream>
//#include <fstream>
//
//
//void main()
//{
//	//char input[100][100];
//	//
//	//std::ifstream inFile("FriendFile.txt");
//	//for (int j = 0; j<100; j++)
//	//	for (int i = 0; i < 100; i++)
//	//	{
//	//		input[j][i] = NULL;
//	//	}
//	//int i = 0;
//	//while (!inFile.eof())
//	//{
//	//	
//	//	inFile.getline(input[i],100);
//	//	i++;
//	//}
//	//
//	//char *list[3][4];
//	//i = i/ 4;
//	//std::cout << i << std::endl;
//	//for(int k=0;k<i;k++)
//	//	for (int j = 0; j < 4; j++)
//	//	{
//	//		list[k][j] = NULL;
//	//	}
//	//for (int k = 0; k<i; k++)
//	//	for (int j = 0; j <4; j++)
//	//	{
//	//		list[k][j] = input[k*4+j];
//	//	}
//	//for (int k = 0; k<i; k++)
//	//	for (int j = 0; j < 4; j++)
//	//{
//	//	std::cout << list[k][j] << std::endl;
//	//}
//	//inFile.close();
//	//char a[100];
//	//std::cin.getline(a, 100);
//	//std::cout << a;
//}