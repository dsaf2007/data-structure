//--------------------------------------------------------------------
//
//                                                          listarr.h
//
//  Class declaration for the array implementation of the List ADT
//
//--------------------------------------------------------------------
// #pragma warning( disable : 4290 )

#include <stdexcept>
#include <iostream>



using namespace std;

const int defMaxListSize = 10;   // Default maximum list size

typedef char DataType;

class List
{
public:

	// Constructor
	List(int maxNumber = defMaxListSize);

	// Destructor
	~List();


	// List manipulation operations
	void read()
		throw (logic_error);
	void insert()    // Insert after cursor
		throw (logic_error);
	void remove()                                 // Remove data item
		throw (logic_error);
       

	// List iteration operations
	int	gotoBeginning()                     // Go to beginning
		throw (logic_error);
	int gotoEnd()                           // Go to end
		throw (logic_error);
	bool gotoNext()                          // Go to next data item
		throw (logic_error);
	bool gotoPrior()                         // Go to prior data item
		throw (logic_error);
	DataType getCursor() const
		throw (logic_error);                // Return data item

	// Output the list structure -- used in testing/debugging
	void showStructure() const;

	// In-lab operations
	bool find(const DataType &searchDataItem)     // Find data item
		throw (logic_error);
	char *list[100][100];
private:
	// Data members
	int maxSize,
		size,             // Actual number of data item in the list
		cursor,
	i;// Cursor array index
	
	//char *dataItems,*list;  // Array containing the list data item
	
};

